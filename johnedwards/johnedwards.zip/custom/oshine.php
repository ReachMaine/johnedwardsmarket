<?php /* customizing of oshine */

function be_themes_fallback_nav_menu(){
    // empty function to stop display of "SET THE MAIN MANU"
	}
